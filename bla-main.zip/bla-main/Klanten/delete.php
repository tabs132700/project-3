<?php
// auteur: Vul hier je naam in
// functie: verwijder een klant op basis van de id
include 'functions.php';

// Haal klant uit de database
if(isset($_GET['id'])){

    // test of delete gelukt is
    if(deleteRecord($_GET['id']) == true){
        echo '<script>alert("Klant met ID: ' . $_GET['id'] . ' is verwijderd")</script>';
        echo "<script> location.replace('klanten.php'); </script>";
    } else {
        echo '<script>alert("Klant is NIET verwijderd")</script>';
    }
}
?>