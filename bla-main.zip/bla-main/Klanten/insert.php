<?php
    // functie: formulier en database insert klant
    // auteur: Vul hier je naam in

    echo "<h1>Nieuwe Klant Toevoegen</h1>";

    require_once('functions.php');
	 
    // Test of er op de insert-knop is gedrukt 
    if(isset($_POST) && isset($_POST['btn_ins'])){
        // test of insert gelukt is
        if(insertRecord($_POST) == true){
            echo "<script>alert('Klant is toegevoegd')</script>";
        } else {
            echo '<script>alert("Klant is NIET toegevoegd")</script>';
        }
    }
?>
<html>
    <body>
        <link rel="stylesheet" href="style.css">
        <form method="post">
        <label for="voornaam">Voornaam:</label>
        <input type="text" id="voornaam" name="voornaam" required><br>

        <label for="achternaam">Achternaam:</label>
        <input type="text" id="achternaam" name="achternaam" required><br>

        <label for="adres">Adres:</label>
        <input type="text" id="adres" name="adres" required><br>

        <label for="postcode">Postcode:</label>
        <input type="text" id="postcode" name="postcode" required><br>

        <label for="plaats">Plaats:</label>
        <input type="text" id="plaats" name="plaats" required><br>

        <label for="telefoon">Telefoon:</label>
        <input type="text" id="telefoon" name="telefoon" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <input type="submit" name="btn_ins" value="Toevoegen">
        </form>
        
        <br><br>
        <a href='klanten.php'>Home</a>
    </body>
</html>