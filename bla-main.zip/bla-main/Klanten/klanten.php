<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoSphere - Klanten Beheer</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <h1 class="title">Auto Webshop</h1>
        <nav class="navbar">
            <a href="http://localhost/Project3-main/Home%20pagina/Home/homepage.html" class="nav-link">Home</a>
            <a href="http://localhost/Project3-main/Home%20pagina/Bestelingen/" class="nav-link">Bestellingen</a>
            <a href="http://localhost/Project3-main/Home%20pagina/Auto_pagina/Auto's/" class="nav-link">Autos</a>
            <a href="http://localhost/Project3-main/Home%20pagina/contact/contact.html" class="nav-link">Contact</a>
            <a href="http://localhost/Project3-main/Home%20pagina/log%20in/login.html" class="nav-link">Log in</a>
        </nav>
    </header>
    <main class="main">
        <div class="content">
            <?php
            // Initialisatie
            include 'functions.php';

            // Main
            // Aanroep functie 
            crudMain();
            ?>
        </div>
    </main>
    
    </footer>
</body>
</html>