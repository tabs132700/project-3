<?php
    // functie: update klant
    // auteur: Vul hier je naam in

    require_once('functions.php');

    // Test of er op de wijzig-knop is gedrukt 
    if(isset($_POST['btn_wzg'])){
        // test of update gelukt is
        if(updateRecord($_POST) == true){
            echo "<script>alert('Klant is gewijzigd')</script>";
        } else {
            echo '<script>alert("Klant is NIET gewijzigd")</script>';
        }
    }

    // Test of id is meegegeven in de URL
    if(isset($_GET['id'])){  
        // Haal alle info van de betreffende id $_GET['id']
        $id = $_GET['id'];
        $row = getRecord($id);
    
?>

<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Wijzig Klant</title>
</head>
<body>
  <h2>Wijzig Klant</h2>
  <form method="post">
    
    <input type="hidden" name="klant_id" required value="<?php echo $row['klant_id']; ?>"><br>
    
    <label for="voornaam">Voornaam:</label>
    <input type="text" id="voornaam" name="voornaam" required value="<?php echo $row['voornaam']; ?>"><br>

    <label for="achternaam">Achternaam:</label>
    <input type="text" id="achternaam" name="achternaam" required value="<?php echo $row['achternaam']; ?>"><br>

    <label for="adres">Adres:</label>
    <input type="text" id="adres" name="adres" required value="<?php echo $row['adres']; ?>"><br>

    <label for="postcode">Postcode:</label>
    <input type="text" id="postcode" name="postcode" required value="<?php echo $row['postcode']; ?>"><br>

    <label for="plaats">Plaats:</label>
    <input type="text" id="plaats" name="plaats" required value="<?php echo $row['plaats']; ?>"><br>

    <label for="telefoon">Telefoon:</label>
    <input type="text" id="telefoon" name="telefoon" required value="<?php echo $row['telefoon']; ?>"><br>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required value="<?php echo $row['email']; ?>"><br>

    <input type="hidden" name="registratie_datum" value="<?php echo $row['registratie_datum']; ?>">

    <input type="submit" name="btn_wzg" value="Wijzig">
  </form>
  <br><br>
  <a href='klanten.php'>Home</a>
</body>
</html>

<?php
    } else {
        echo "Geen id opgegeven<br>";
    }
?>