<?php
// Definieer databasegegevens als constanten
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");
define("DATABASE", "autowebshop");


?>