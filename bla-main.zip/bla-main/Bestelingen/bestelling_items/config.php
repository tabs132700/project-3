<?php
// auteur: Thierry Chatoorang
// functie: configuratiebestand

define("DATABASE", "autowebshop");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

define("CRUD_TABLE", "bestellingen_items");
?>