
<?php
// Database connection settings
$host = 'localhost';
$dbname = 'autowebshop';
$username = 'root';
$password = '';

session_start();

try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user = $_POST['username'];
        $pass = $_POST['password'];

        // Fetch user from the database
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $user);
        $stmt->execute();
        $userRecord = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($userRecord && password_verify($pass, $userRecord['password'])) {
            // Login successful
            $_SESSION['user_id'] = $userRecord['id'];
            $_SESSION['username'] = $userRecord['username'];
            header('Location:http://localhost/Project3-main/Home%20pagina/Home/homepage.html');
        } else {
            // Login failed
            echo 'Ongeldige gebruikersnaam of wachtwoord.';
        }
    }
} catch (PDOException $e) {
    echo 'Databasefout: ' . $e->getMessage();
}
?>