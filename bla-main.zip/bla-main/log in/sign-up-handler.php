
<?php
// Database connection settings
$host = 'localhost';
$dbname = 'autowebshop';
$username = 'root';
$password = '';

try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user = $_POST['username'];
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $confirmPass = $_POST['confirm-password'];

        // Validate passwords
        if ($pass !== $confirmPass) {
            die('Wachtwoorden komen niet overeen.');
        }

        // Hash the password for security
        $hashedPassword = password_hash($pass, PASSWORD_DEFAULT);

        // Insert user data into the database
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
        $stmt->bindParam(':username', $user);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword);

        if ($stmt->execute()) {
            header('Location: login.html');
        } else {
            echo 'Er is een fout opgetreden. Probeer het opnieuw.';
        }
    }
} catch (PDOException $e) {
    echo 'Databasefout: ' . $e->getMessage();
}
?>