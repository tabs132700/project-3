<?php
// auteur: Senay
// functie: algemene functies voor CRUD Merken

include_once "config.php";

function connectDb() {
    $servername = SERVERNAME;
    $username = USERNAME;
    $password = PASSWORD;
    $dbname = DATABASE;

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $conn;
    } catch(PDOException $e) {
        die("Connectie mislukt: " . $e->getMessage());
    }
}

function crudMain() {
    echo "
    <h1>CRUD Merken</h1>
    <nav>
        <a href='insert.php'>Nieuw Merk Toevoegen</a>
    </nav><br>";

    $result = getData(CRUD_TABLE);
    printCrudTabel($result);
}

function getData($table) {
    $conn = connectDb();
    $sql = "SELECT * FROM $table";
    $query = $conn->prepare($sql);
    $query->execute();
    return $query->fetchAll();
}

function getRecord($id) {
    $conn = connectDb();
    $sql = "SELECT * FROM " . CRUD_TABLE . " WHERE merk_id = :merk_id";
    $query = $conn->prepare($sql);
    $query->execute([':merk_id' => $id]);
    return $query->fetch();
}

function printCrudTabel($result) {
    $table = "<table border='1'>";
    $headers = array_keys($result[0]);
    $table .= "<tr>";
    foreach($headers as $header) {
        $table .= "<th>" . $header . "</th>";   
    }
    $table .= "<th colspan='2'>Actie</th></tr>";

    foreach ($result as $row) {
        $table .= "<tr>";
        foreach ($row as $cell) {
            $table .= "<td>" . $cell . "</td>";  
        }
        $table .= "<td><form method='post' action='update.php?merk_id=" . $row['merk_id'] . "'><button>Bewerken</button></form></td>";
        $table .= "<td><form method='post' action='delete.php?merk_id=" . $row['merk_id'] . "'><button>Verwijderen</button></form></td>";
        $table .= "</tr>";
    }
    $table .= "</table>";
    echo $table;
}

function updateRecord($row) {
    $conn = connectDb();
    $sql = "UPDATE " . CRUD_TABLE . " SET 
        naam = :naam, 
        land_van_herkomst = :land_van_herkomst, 
        beschrijving = :beschrijving 
        WHERE merk_id = :merk_id";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        ':naam' => $row['naam'],
        ':land_van_herkomst' => $row['land_van_herkomst'],
        ':beschrijving' => $row['beschrijving'],
        ':merk_id' => $row['merk_id']
    ]);
}

function insertRecord($post) {
    $conn = connectDb();
    $sql = "INSERT INTO " . CRUD_TABLE . " (naam, land_van_herkomst, beschrijving) 
            VALUES (:naam, :land_van_herkomst, :beschrijving)";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        ':naam' => $_POST['naam'],
        ':land_van_herkomst' => $_POST['land_van_herkomst'],
        ':beschrijving' => $_POST['beschrijving']
    ]);
}

function deleteRecord($id) {
    $conn = connectDb();
    $sql = "DELETE FROM " . CRUD_TABLE . " WHERE merk_id = :merk_id";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([':merk_id' => $id]);
}
?>