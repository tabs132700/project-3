<?php
require_once('functions.php');

if (isset($_POST['btn_wzg'])) {
    if (updateRecord($_POST)) {
        echo "<script>alert('Merk bijgewerkt!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Fout bij bijwerken.');</script>";
    }
}

if (isset($_GET['merk_id'])) {
    $id = $_GET['merk_id'];
    $row = getRecord($id);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bewerk Merk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Bewerk Merk</h2>
    <form method="post">
        <input type="hidden" name="merk_id" value="<?= $row['merk_id'] ?>">
        
        <label for="naam">Naam:</label>
        <input type="text" id="naam" name="naam" value="<?= $row['naam'] ?>" required><br>

        <label for="land">Land:</label>
        <input type="text" id="land" name="land_van_herkomst" value="<?= $row['land_van_herkomst'] ?>" required><br>

        <label for="beschrijving">Beschrijving:</label>
        <textarea id="beschrijving" name="beschrijving" required><?= $row['beschrijving'] ?></textarea><br>

        <input type="submit" name="btn_wzg" value="Opslaan">
        <a href='index.php'>Annuleren</a>
    </form>
</body>
</html>
<?php } ?>