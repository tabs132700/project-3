<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Merken</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <h1> <a href="http://localhost/project%203/Auto%20webshop/Home%20pagina/Auto_pagina/Auto's/index.php">Auto's Beheren</a> </h1>
    <?php
    include 'functions.php';
    crudMain();
    ?>
</body>
</html>