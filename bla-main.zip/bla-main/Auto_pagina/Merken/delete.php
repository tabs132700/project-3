<?php
require_once('functions.php');

if (isset($_GET['merk_id'])) {
    if (deleteRecord($_GET['merk_id'])) {
        echo "<script>alert('Merk verwijderd!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Fout bij verwijderen.');</script>";
    }
}
?>
