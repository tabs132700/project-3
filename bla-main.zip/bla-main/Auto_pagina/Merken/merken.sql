-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 24 mrt 2025 om 11:34
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autowebshop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `merken`
--

CREATE TABLE `merken` (
  `merk_id` int(11) NOT NULL,
  `naam` varchar(50) NOT NULL,
  `land_van_herkomst` varchar(50) DEFAULT NULL,
  `beschrijving` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `merken`
--

INSERT INTO `merken` (`merk_id`, `naam`, `land_van_herkomst`, `beschrijving`) VALUES
(1, 'BMW', 'Duitsland', 'Bayerische Motoren Werke AG, bekend als BMW, is een Duitse fabrikant van luxe voertuigen en motorfietsen.'),
(2, 'Audi', 'Duitsland', 'Audi AG is een Duitse autofabrikant die luxe voertuigen ontwerpt, ontwikkelt, produceert en verkoopt.'),
(3, 'Volkswagen', 'Duitsland', 'Volkswagen is een Duitse autofabrikant die bekend staat om zijn betrouwbare en betaalbare auto\'s.'),
(4, 'Mercedes', 'Duitsland', 'Mercedes-Benz, vaak simpelweg Mercedes genoemd, is een Duitse autofabrikant van luxe en premium voertuigen.'),
(5, 'Opel', 'Duitsland', 'Opel is een Duitse autofabrikant die betaalbare en praktische auto\'s produceert.'),
(6, 'Ford', 'Verenigde Staten', 'Ford Motor Company is een Amerikaanse autofabrikant met een breed assortiment voertuigen.'),
(7, 'Peugeot', 'Frankrijk', 'Peugeot is een Franse autofabrikant bekend om zijn stijlvolle en innovatieve modellen.'),
(8, 'Renault', 'Frankrijk', 'Renault is een Franse autofabrikant met een breed aanbod van voertuigen.'),
(9, 'Citroën', 'Frankrijk', 'Citroën is een Franse autofabrikant bekend om zijn innovatieve ontwerpen en comfortabele rijervaring.'),
(10, 'Toyota', 'Japan', 'Toyota is een Japanse autofabrikant bekend om zijn betrouwbare en duurzame voertuigen.'),
(11, 'Honda', 'Japan', 'Honda is een Japanse fabrikant van auto\'s, motorfietsen en andere machines.'),
(12, 'Nissan', 'Japan', 'Nissan is een Japanse autofabrikant met een breed scala aan voertuigen.'),
(13, 'Kia', 'Zuid-Korea', 'Kia is een Zuid-Koreaanse autofabrikant bekend om zijn betaalbare en goed uitgeruste auto\'s.'),
(14, 'Mazda', 'Japan', 'Mazda is een Japanse autofabrikant bekend om zijn sportieve en dynamische rijervaring.'),
(15, 'Skoda', 'Tsjechië', 'Skoda is een Tsjechische autofabrikant die betrouwbare en praktische auto\'s produceert.');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `merken`
--
ALTER TABLE `merken`
  ADD PRIMARY KEY (`merk_id`),
  ADD UNIQUE KEY `naam` (`naam`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `merken`
--
ALTER TABLE `merken`
  MODIFY `merk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
