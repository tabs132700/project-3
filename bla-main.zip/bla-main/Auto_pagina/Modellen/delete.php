<?php
require_once('functions.php');

if (isset($_GET['model_id'])) {
    if (deleteRecord($_GET['model_id'])) {
        echo "<script>alert('Model verwijderd!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Fout bij verwijderen.');</script>";
    }
}
?>