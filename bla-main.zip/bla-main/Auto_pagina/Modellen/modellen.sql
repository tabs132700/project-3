-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 31 mrt 2025 om 11:39
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autowebshop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `modellen`
--

CREATE TABLE `modellen` (
  `model_id` int(11) NOT NULL,
  `merk_id` int(11) NOT NULL,
  `naam` varchar(50) NOT NULL,
  `beschrijving` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `modellen`
--

INSERT INTO `modellen` (`model_id`, `merk_id`, `naam`, `beschrijving`) VALUES
(1, 1, '114', 'Compacte BMW hatchback'),
(2, 1, 'X5', 'Luxe SUV van BMW'),
(3, 2, 'A3', 'Compacte premium hatchback van Audi'),
(4, 3, 'Golf', 'Populaire middenklasse hatchback van Volkswagen'),
(5, 4, 'A-Class', 'Compacte luxe hatchback van Mercedes'),
(6, 5, 'Corsa', 'Compacte stadsauto van Opel'),
(7, 6, 'Focus', 'Middenklasse hatchback van Ford'),
(8, 7, '208', 'Compacte stadsauto van Peugeot'),
(9, 8, 'Clio', 'Compacte stadsauto van Renault'),
(10, 9, 'C3', 'Compacte stadsauto van Citroën'),
(11, 10, 'Yaris', 'Compacte stadsauto van Toyota'),
(12, 11, 'Civic', 'Middenklasse hatchback van Honda'),
(13, 12, 'Micra', 'Compacte stadsauto van Nissan'),
(14, 13, 'Sportage', 'Compacte SUV van Kia'),
(15, 14, '3', 'Middenklasse hatchback van Mazda'),
(16, 15, 'Octavia', 'Ruime middenklasse auto van Skoda');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `modellen`
--
ALTER TABLE `modellen`
  ADD PRIMARY KEY (`model_id`),
  ADD KEY `merk_id` (`merk_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `modellen`
--
ALTER TABLE `modellen`
  MODIFY `model_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `modellen`
--
ALTER TABLE `modellen`
  ADD CONSTRAINT `modellen_ibfk_1` FOREIGN KEY (`merk_id`) REFERENCES `merken` (`merk_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
