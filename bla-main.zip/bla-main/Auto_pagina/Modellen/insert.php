<?php
require_once('functions.php');

if (isset($_POST['btn_ins'])) {
    if (insertRecord($_POST)) {
        echo "<script>alert('Model toegevoegd!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Fout bij toevoegen.');</script>";
    }
}

$merken = getMerken();
?>

<html>
<body>
    <h2>Nieuw Model Toevoegen</h2>
    <form method="post">
        <label for="merk_id">Merk:</label>
        <select id="merk_id" name="merk_id" required>
            <?php foreach ($merken as $merk): ?>
                <option value="<?= $merk['merk_id'] ?>"><?= $merk['naam'] ?></option>
            <?php endforeach; ?>
        </select><br>

        <label for="naam">Modelnaam:</label>
        <input type="text" id="naam" name="naam" required><br>

        <label for="beschrijving">Beschrijving:</label>
        <textarea id="beschrijving" name="beschrijving" required></textarea><br>

        <input type="submit" name="btn_ins" value="Toevoegen">
        <a href='index.php'>Annuleren</a>
    </form>
</body>
</html>