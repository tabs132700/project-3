<?php
// auteur: Senay
// functie: algemene functies voor CRUD Modellen

include_once "config.php";

function connectDb() {
    $servername = SERVERNAME;
    $username = USERNAME;
    $password = PASSWORD;
    $dbname = DATABASE;

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Connectie mislukt: " . $e->getMessage());
    }
}

function crudMain() {
    echo "
    <h1>CRUD Modellen</h1>
    <nav>
        <a href='insert.php'>Nieuw Model Toevoegen</a>
    </nav><br>";

    $result = getDataWithBrands();
    printCrudTabel($result);
}

function getDataWithBrands() {
    $conn = connectDb();
    $sql = "SELECT m.model_id, mk.naam AS merk_naam, m.naam AS model_naam, m.beschrijving 
            FROM modellen m
            JOIN merken mk ON m.merk_id = mk.merk_id";
    $query = $conn->prepare($sql);
    $query->execute();
    return $query->fetchAll();
}

function getRecord($id) {
    $conn = connectDb();
    $sql = "SELECT * FROM modellen WHERE model_id = :model_id";
    $query = $conn->prepare($sql);
    $query->execute([':model_id' => $id]);
    return $query->fetch();
}

function printCrudTabel($result) {
    $table = "<table border='1'>";
    $headers = ["Model ID", "Merk", "Modelnaam", "Beschrijving"];
    $table .= "<tr>";
    foreach($headers as $header) {
        $table .= "<th>" . $header . "</th>";   
    }
    $table .= "<th colspan='2'>Actie</th></tr>";

    foreach ($result as $row) {
        $table .= "<tr>";
        $table .= "<td>" . $row['model_id'] . "</td>";
        $table .= "<td>" . $row['merk_naam'] . "</td>";
        $table .= "<td>" . $row['model_naam'] . "</td>";
        $table .= "<td>" . $row['beschrijving'] . "</td>";
        $table .= "<td><form method='post' action='update.php?model_id=" . $row['model_id'] . "'><button>Bewerken</button></form></td>";
        $table .= "<td><form method='post' action='delete.php?model_id=" . $row['model_id'] . "'><button>Verwijderen</button></form></td>";
        $table .= "</tr>";
    }
    $table .= "</table>";
    echo $table;
}

function updateRecord($row) {
    $conn = connectDb();
    $sql = "UPDATE modellen SET 
            merk_id = :merk_id, 
            naam = :naam, 
            beschrijving = :beschrijving 
            WHERE model_id = :model_id";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        ':merk_id' => $row['merk_id'],
        ':naam' => $row['naam'],
        ':beschrijving' => $row['beschrijving'],
        ':model_id' => $row['model_id']
    ]);
}

function insertRecord($post) {
    $conn = connectDb();
    $sql = "INSERT INTO modellen (merk_id, naam, beschrijving) 
            VALUES (:merk_id, :naam, :beschrijving)";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        ':merk_id' => $_POST['merk_id'],
        ':naam' => $_POST['naam'],
        ':beschrijving' => $_POST['beschrijving']
    ]);
}

function deleteRecord($id) {
    $conn = connectDb();
    $sql = "DELETE FROM modellen WHERE model_id = :model_id";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([':model_id' => $id]);
}

function getMerken() {
    $conn = connectDb();
    $sql = "SELECT merk_id, naam FROM merken";
    $query = $conn->prepare($sql);
    $query->execute();
    return $query->fetchAll();
}
?>