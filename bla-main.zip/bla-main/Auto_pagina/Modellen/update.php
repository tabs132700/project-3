<?php
require_once('functions.php');

if (isset($_POST['btn_wzg'])) {
    if (updateRecord($_POST)) {
        echo "<script>alert('Model bijgewerkt!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Fout bij bijwerken.');</script>";
    }
}

if (isset($_GET['model_id'])) {
    $id = $_GET['model_id'];
    $row = getRecord($id);
    $merken = getMerken();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bewerk Model</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Bewerk Model</h2>
    <form method="post">
        <input type="hidden" name="model_id" value="<?= $row['model_id'] ?>">
        
        <label for="merk_id">Merk:</label>
        <select id="merk_id" name="merk_id" required>
            <?php foreach ($merken as $merk): ?>
                <option value="<?= $merk['merk_id'] ?>" <?= $merk['merk_id'] == $row['merk_id'] ? 'selected' : '' ?>>
                    <?= $merk['naam'] ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="naam">Modelnaam:</label>
        <input type="text" id="naam" name="naam" value="<?= $row['naam'] ?>" required><br>

        <label for="beschrijving">Beschrijving:</label>
        <textarea id="beschrijving" name="beschrijving" required><?= $row['beschrijving'] ?></textarea><br>

        <input type="submit" name="btn_wzg" value="Opslaan">
        <a href='index.php'>Annuleren</a>
    </form>
</body>
</html>
<?php } ?>