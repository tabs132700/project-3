<?php
// auteur: [Your Name]
// functie: algemene functies voor auto_fotos CRUD

include_once "config.php";

function connectDb(){
    $servername = SERVERNAME;
    $username = USERNAME;
    $password = PASSWORD;
    $dbname = DATABASE;
   
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $conn;
    } 
    catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }
}

function crudMain(){
    // Menu-item insert
    $txt = "
    <h1>Crud Auto Fotos</h1>
    <nav>
		<a href='insert.php'>Toevoegen nieuwe foto</a>
    </nav><br>";
    echo $txt;

    // Haal alle foto records uit de tabel 
    $result = getData(CRUD_TABLE);

    //print table
    printCrudTabel($result);
}

// selecteer de data uit de opgeven table
function getData($table){
    $conn = connectDb();

    $sql = "SELECT * FROM $table";
    $query = $conn->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();

    return $result;
}

// selecteer de rij van de opgeven id uit de table auto_fotos
function getRecord($id){
    $conn = connectDb();

    $sql = "SELECT * FROM " . CRUD_TABLE . " WHERE foto_id = :id";
    $query = $conn->prepare($sql);
    $query->execute([':id'=>$id]);
    $result = $query->fetch();

    return $result;
}

// Haal alle fotos voor een specifieke auto
function getAutoFotos($auto_id){
    $conn = connectDb();

    $sql = "SELECT * FROM " . CRUD_TABLE . " WHERE auto_id = :auto_id ORDER BY primaire_foto DESC";
    $query = $conn->prepare($sql);
    $query->execute([':auto_id'=>$auto_id]);
    $result = $query->fetchAll();

    return $result;
}

// Function 'printCrudTabel' print een HTML-table met data uit $result 
function printCrudTabel($result){
    if (empty($result)) {
        echo "<p>Geen records gevonden</p>";
        return;
    }
    
    $table = "<table>";

    // Print header table
    $headers = array_keys($result[0]);
    $table .= "<tr>";
    foreach($headers as $header){
        $table .= "<th>" . $header . "</th>";   
    }
    // Voeg image en actie kopregel toe
    $table .= "<th>Afbeelding</th>";
    $table .= "<th colspan=2>Actie</th>";
    $table .= "</tr>";

    // print elke rij
    foreach ($result as $row) {
        $table .= "<tr>";
        // print elke kolom
        foreach ($row as $cell) {
            $table .= "<td>" . $cell . "</td>";  
        }
        
        // Toon afbeelding
        $table .= "<td>";
        if (file_exists("uploads/" . $row['bestandsnaam'])) {
            $table .= "<img src='uploads/" . $row['bestandsnaam'] . "' alt='Afbeelding' style='max-width: 100px; max-height: 100px;'>";
        } else {
            $table .= "Afbeelding niet gevonden";
        }
        $table .= "</td>";
        
        // Wijzig knopje
        $table .= "<td>
            <form method='post' action='update.php?id=$row[foto_id]' >       
                <button>update</button>	 
            </form></td>";

        // Delete knopje
        $table .= "<td>
            <form method='post' action='delete.php?id=$row[foto_id]' >       
                <button>Verwijder</button>	 
            </form></td>";

        $table .= "</tr>";
    }
    $table.= "</table>";

    echo $table;
}

function updateRecord($row){
    $conn = connectDb();

    $sql = "UPDATE " . CRUD_TABLE . "
    SET 
        auto_id = :auto_id, 
        bestandsnaam = :bestandsnaam,
        primaire_foto = :primaire_foto
    WHERE foto_id = :id
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':auto_id'=>$row['auto_id'],
        ':bestandsnaam'=>$row['bestandsnaam'],
        ':primaire_foto'=>isset($row['primaire_foto']) ? $row['primaire_foto'] : 0,
        ':id'=>$row['foto_id']
    ]);

    $retVal = ($stmt->rowCount() == 1) ? true : false ;
    return $retVal;
}

function insertRecord($post){
    $conn = connectDb();

    $bestandsnaam = "";
    
    // Controleer of er een bestand is geüpload
    if(isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $upload_dir = 'uploads/';
        
        // Maak upload directory als deze niet bestaat
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // Genereer unieke bestandsnaam
        $bestandsnaam = time() . '_' . basename($_FILES['foto']['name']);
        $target_file = $upload_dir . $bestandsnaam;
        
        // Verplaats het geüploade bestand
        if(move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
            // Bestand is geüpload
        } else {
            throw new Exception("Fout bij uploaden van bestand.");
        }
    } else if(isset($_POST['bestandsnaam']) && !empty($_POST['bestandsnaam'])) {
        // Als geen bestand geüpload maar wel bestandsnaam opgegeven
        $bestandsnaam = $_POST['bestandsnaam'];
    } else {
        throw new Exception("Geen bestand geüpload of bestandsnaam opgegeven.");
    }
    
    $sql = "
        INSERT INTO " . CRUD_TABLE . " (auto_id, bestandsnaam, primaire_foto, datum_toegevoegd)
        VALUES (:auto_id, :bestandsnaam, :primaire_foto, NOW()) 
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':auto_id'=>$_POST['auto_id'],
        ':bestandsnaam'=>$bestandsnaam,
        ':primaire_foto'=>isset($_POST['primaire_foto']) ? $_POST['primaire_foto'] : 0
    ]);

    $retVal = ($stmt->rowCount() == 1) ? true : false ;
    return $retVal;  
}

function deleteRecord($id){
    $conn = connectDb();
    
    // Haal eerst het record op voor we het verwijderen (om bestand te kunnen verwijderen)
    $sql = "SELECT bestandsnaam FROM " . CRUD_TABLE . " WHERE foto_id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id' => $id]);
    $record = $stmt->fetch();
    
    if($record) {
        // Verwijder het bestand als het bestaat
        $bestandspad = 'uploads/' . $record['bestandsnaam'];
        if(file_exists($bestandspad)) {
            unlink($bestandspad);
        }
    }
    
    // Verwijder het database record
    $sql = "DELETE FROM " . CRUD_TABLE . " WHERE foto_id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id' => $id]);

    $retVal = ($stmt->rowCount() == 1) ? true : false ;
    return $retVal;
}

// Functie om primaire foto in te stellen en andere op 0 te zetten
function setPrimaireFoto($foto_id, $auto_id) {
    $conn = connectDb();
    
    // Begin transactie
    $conn->beginTransaction();
    
    try {
        // Reset alle foto's voor deze auto naar niet-primair
        $resetSql = "UPDATE " . CRUD_TABLE . " SET primaire_foto = 0 WHERE auto_id = :auto_id";
        $resetStmt = $conn->prepare($resetSql);
        $resetStmt->execute([':auto_id' => $auto_id]);
        
        // Stel de geselecteerde foto in als primair
        $updateSql = "UPDATE " . CRUD_TABLE . " SET primaire_foto = 1 WHERE foto_id = :foto_id";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->execute([':foto_id' => $foto_id]);
        
        // Commit transactie
        $conn->commit();
        return true;
    } catch (Exception $e) {
        // Rollback transactie bij fout
        $conn->rollBack();
        return false;
    }
}
?>