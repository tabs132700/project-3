<?php
// auteur: [Your Name]
// functie: verwijder een auto_foto op basis van de id
include 'functions.php';

// Haal foto uit de database
if(isset($_GET['id'])){
    try {
        // test of verwijderen gelukt is
        if(deleteRecord($_GET['id']) == true){
            echo '<script>alert("Foto: ' . $_GET['id'] . ' is verwijderd")</script>';
            echo "<script> location.replace('home.php'); </script>";
        }
    } catch (Exception $e) {
        echo '<script>alert("' . $e->getMessage() . '")</script>';
        echo "<script> location.replace('home.php'); </script>";
    }
}
?>