<?php
    // functie: update auto_fotos
    // auteur: [Your Name]

    require_once('functions.php');

    // Test of er op de wijzig-knop is gedrukt 
    if(isset($_POST['btn_wzg'])){
        try {
            $post_data = $_POST;
            
            // Controleer of er een bestand is geüpload
            if(isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
                $upload_dir = 'uploads/';
                
                // Maak upload directory als deze niet bestaat
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                // Genereer unieke bestandsnaam
                $bestandsnaam = time() . '_' . basename($_FILES['foto']['name']);
                $target_file = $upload_dir . $bestandsnaam;
                
                // Verplaats het geüploade bestand
                if(move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
                    $post_data['bestandsnaam'] = $bestandsnaam;
                    
                    // Verwijder oude bestand als er een nieuwe upload is
                    $old_record = getRecord($_POST['foto_id']);
                    if($old_record && $old_record['bestandsnaam'] != $bestandsnaam) {
                        $old_file = 'uploads/' . $old_record['bestandsnaam'];
                        if(file_exists($old_file)) {
                            unlink($old_file);
                        }
                    }
                } else {
                    throw new Exception("Fout bij uploaden van bestand.");
                }
            }
            
            // test of update gelukt is
            if(updateRecord($post_data) == true){
                echo "<script>alert('Foto is gewijzigd')</script>";
                
                if(isset($_POST['auto_id'])) {
                    echo "<script>window.location.href = 'view_auto.php?auto_id=" . $_POST['auto_id'] . "';</script>";
                } else {
                    echo "<script>window.location.href = 'home.php';</script>";
                }
            } else {
                echo '<script>alert("Foto is NIET gewijzigd")</script>';
            }
        } catch (Exception $e) {
            echo '<script>alert("Fout: ' . $e->getMessage() . '")</script>';
        }
    }

    // Test of id is meegegeven in de URL
    if(isset($_GET['id'])){  
        // Haal alle info van de betreffende id $_GET['id']
        $id = $_GET['id'];
        $row = getRecord($id);
    
?>

<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Wijzig Auto Foto</title>
</head>
<body>
  <h2>Wijzig Auto Foto</h2>
  
  <?php if(file_exists("uploads/" . $row['bestandsnaam'])): ?>
      <div style="margin-bottom: 20px;">
          <p>Huidige afbeelding:</p>
          <img src="uploads/<?php echo $row['bestandsnaam']; ?>" alt="Huidige foto" style="max-width: 300px; max-height: 300px;">
      </div>
  <?php endif; ?>
  
  <form method="post" enctype="multipart/form-data">
    
    <input type="hidden" id="foto_id" name="foto_id" required value="<?php echo $row['foto_id']; ?>">
    
    <label for="auto_id">Auto ID:</label>
    <input type="number" id="auto_id" name="auto_id" required value="<?php echo $row['auto_id']; ?>"><br>

    <label for="bestandsnaam">Huidige bestandsnaam:</label>
    <input type="text" id="bestandsnaam" name="bestandsnaam" required value="<?php echo $row['bestandsnaam']; ?>"><br>

    <label for="foto">Vervang foto (optioneel):</label>
    <input type="file" id="foto" name="foto" accept="image/*"><br>

    <label for="primaire_foto">Primaire foto:</label>
    <select id="primaire_foto" name="primaire_foto">
        <option value="0" <?php echo ($row['primaire_foto'] == 0) ? 'selected' : ''; ?>>Nee</option>
        <option value="1" <?php echo ($row['primaire_foto'] == 1) ? 'selected' : ''; ?>>Ja</option>
    </select><br>

    <input type="submit" name="btn_wzg" value="Wijzig">
  </form>
  <br><br>
  <a href='home.php'>Home</a>
  <?php if(isset($row['auto_id'])): ?>
    <a href='view_auto.php?auto_id=<?php echo $row['auto_id']; ?>'>Terug naar auto foto's</a>
  <?php endif; ?>
</body>
</html>

<?php
    } else {
        echo "Geen id opgegeven<br>";
    }
?>