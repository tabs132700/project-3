<?php
// auteur: [Your Name]
// functie: Toon alle fotos van een specifieke auto

require_once('functions.php');

// Controleer of auto_id is doorgegeven
if (!isset($_GET['auto_id'])) {
    echo "Geen auto_id opgegeven!";
    exit;
}

$auto_id = $_GET['auto_id'];
$fotos = getAutoFotos($auto_id);

// Verwerk primaire foto actie
if (isset($_GET['set_primair'])) {
    $foto_id = $_GET['set_primair'];
    if (setPrimaireFoto($foto_id, $auto_id)) {
        echo "<script>alert('Primaire foto ingesteld!')</script>";
        echo "<script>window.location.href = 'view_auto.php?auto_id=" . $auto_id . "';</script>";
    } else {
        echo "<script>alert('Fout bij instellen primaire foto!')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Fotos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Foto's voor Auto ID: <?php echo $auto_id; ?></h1>
    
    <?php if (empty($fotos)): ?>
        <p>Geen foto's gevonden voor deze auto.</p>
    <?php else: ?>
        <div class="foto-gallery">
            <?php foreach($fotos as $foto): ?>
                <div class="foto-item">
                    <?php if (file_exists("uploads/" . $foto['bestandsnaam'])): ?>
                        <img src="uploads/<?php echo $foto['bestandsnaam']; ?>" alt="Auto foto">
                    <?php else: ?>
                        <div style="width: 200px; height: 150px; background-color: #eee; display: flex; align-items: center; justify-content: center;">
                            Afbeelding niet gevonden
                        </div>
                    <?php endif; ?>
                    
                    <div class="foto-info">
                        ID: <?php echo $foto['foto_id']; ?>
                        <?php if ($foto['primaire_foto'] == 1): ?>
                            <span class="primair-badge">Primair</span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="foto-info">
                        Bestandsnaam: <?php echo $foto['bestandsnaam']; ?>
                    </div>
                    
                    <div class="foto-info">
                        Toegevoegd: <?php echo $foto['datum_toegevoegd']; ?>
                    </div>
                    
                    <div class="foto-actions">
                        <?php if ($foto['primaire_foto'] != 1): ?>
                            <a href="view_auto.php?auto_id=<?php echo $auto_id; ?>&set_primair=<?php echo $foto['foto_id']; ?>">
                                <button>Maak primair</button>
                            </a>
                        <?php endif; ?>
                        
                        <a href="update.php?id=<?php echo $foto['foto_id']; ?>">
                            <button>Bewerken</button>
                        </a>
                        
                        <a href="delete.php?id=<?php echo $foto['foto_id']; ?>" onclick="return confirm('Weet u zeker dat u deze foto wilt verwijderen?');">
                            <button>Verwijderen</button>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <div style="margin-top: 20px;">
        <a href="insert.php?auto_id=<?php echo $auto_id; ?>">
            <button>Voeg nieuwe foto toe</button>
        </a>
        <a href="home.php">
            <button>Terug naar overzicht</button>
        </a>
    </div>
</body>
</html>