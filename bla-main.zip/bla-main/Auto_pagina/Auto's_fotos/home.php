<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Auto Fotos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <main class="container">
    <section class="producten-grid">

   <h1> <a href="http://localhost/project%203/Auto%20webshop/Home%20pagina/Auto_pagina/Auto's/index.php">Auto's Beheren</a> </h1>

    <?php
    // functie: Programma CRUD auto_fotos
    // auteur: [Your Name]

    // Initialisatie
    include 'functions.php';

    // Main
    // Aanroep functie 
    crudMain();
    ?>

    </section>
    </main>

    <footer class="footer">
        <p>2025</p>
    </footer>
</body>
</html>