<?php
// auteur: [Your Name]
// functie: config voor auto_fotos CRUD

define("DATABASE", "autowebshop");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

define("CRUD_TABLE", "auto_fotos");

?>