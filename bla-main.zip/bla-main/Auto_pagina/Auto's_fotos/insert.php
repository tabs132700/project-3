<?php
    // functie: formulier en database insert auto_fotos
    // auteur: [Your Name]

    echo "<h1>Insert Auto Foto</h1>";

    require_once('functions.php');
	 
    // Test of er op de insert-knop is gedrukt 
    if(isset($_POST) && isset($_POST['btn_ins'])){
        try {
            // test of insert gelukt is
            if(insertRecord($_POST) == true){
                echo "<script>alert('Foto is toegevoegd')</script>";
                echo "<script> location.replace('home.php'); </script>";
            } else {
                echo '<script>alert("Foto is NIET toegevoegd")</script>';
            }
        } catch (Exception $e) {
            echo '<script>alert("Fout: ' . $e->getMessage() . '")</script>';
        }
    }
?>
<html>
    <link rel="stylesheet" href="style.css">
    <body>
        <form method="post" enctype="multipart/form-data">
        <label for="auto_id">Auto ID:</label>
        <input type="number" id="auto_id" name="auto_id" required><br>

        <label for="foto">Foto uploaden:</label>
        <input type="file" id="foto" name="foto" accept="image/*"><br>

        <p>OF</p>

        <label for="bestandsnaam">Bestandsnaam (als geen upload):</label>
        <input type="text" id="bestandsnaam" name="bestandsnaam"><br>

        <label for="primaire_foto">Primaire foto:</label>
        <select id="primaire_foto" name="primaire_foto">
            <option value="0">Nee</option>
            <option value="1">Ja</option>
        </select><br>

        <input type="submit" name="btn_ins" value="Insert">
        </form>
        
        <br><br>
        <a href='home.php'>Home</a>
    </body>
</html>