<?php
// auteur: [Your Name]
// functie: creëer de auto_fotos tabel

include 'config.php';

function createAutoFotosTable() {
    $servername = SERVERNAME;
    $username = USERNAME;
    $password = PASSWORD;
    $dbname = DATABASE;
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // SQL om tabel aan te maken
        $sql = "CREATE TABLE IF NOT EXISTS auto_fotos (
            foto_id INT(11) NOT NULL AUTO_INCREMENT,
            auto_id INT(11) NOT NULL,
            bestandsnaam VARCHAR(255) COLLATE utf8mb4_general_ci NOT NULL,
            primaire_foto TINYINT(1) DEFAULT NULL,
            datum_toegevoegd DATETIME NOT NULL,
            PRIMARY KEY (foto_id)
        )";
        
        // Voer query uit
        $conn->exec($sql);
        echo "Tabel auto_fotos succesvol aangemaakt!";
    } catch(PDOException $e) {
        echo "Fout bij aanmaken tabel: " . $e->getMessage();
    }
    
    $conn = null;
}

// Aanroep functie
createAutoFotosTable();
?>