<?php
require_once 'functions.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];
$auto = getAutoById($id);

if (!$auto) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'model_id' => $_POST['model_id'],
        'merk_id' => $_POST['merk_id'],
        'bouwjaar' => $_POST['bouwjaar'],
        'kleur' => $_POST['kleur'],
        'kilometerstand' => $_POST['kilometerstand'],
        'brandstof' => $_POST['brandstof'],
        'transmissie' => $_POST['transmissie'],
        'prijs' => $_POST['prijs'],
        'beschrijving' => $_POST['beschrijving'],
        'voorraad' => $_POST['voorraad'],
        'leverancier_id' => $_POST['leverancier_id'],
        'datum_toegevoegd' => $_POST['datum_toegevoegd'],
        'verkocht' => $_POST['verkocht'] ?? 0
    ];
    
    if (updateAuto($id, $data)) {
        header("Location: index.php?success=1");
        exit();
    } else {
        $error = "Er is een fout opgetreden bij het bijwerken van de auto.";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Bewerken</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Auto Bewerken</h1>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="merk_id" class="form-label">Merk ID</label>
                        <input type="number" class="form-control" id="merk_id" name="merk_id" value="<?= htmlspecialchars($auto['merk_id']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="model_id" class="form-label">Model ID</label>
                        <input type="number" class="form-control" id="model_id" name="model_id" value="<?= htmlspecialchars($auto['model_id']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="bouwjaar" class="form-label">Bouwjaar</label>
                        <input type="number" class="form-control" id="bouwjaar" name="bouwjaar" min="1900" max="<?= date('Y') + 1 ?>" value="<?= htmlspecialchars($auto['bouwjaar']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="kleur" class="form-label">Kleur</label>
                        <input type="text" class="form-control" id="kleur" name="kleur" value="<?= htmlspecialchars($auto['kleur']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="kilometerstand" class="form-label">Kilometerstand</label>
                        <input type="number" class="form-control" id="kilometerstand" name="kilometerstand" min="0" value="<?= htmlspecialchars($auto['kilometerstand']) ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="brandstof" class="form-label">Brandstof</label>
                        <select class="form-select" id="brandstof" name="brandstof" required>
                            <option value="Benzine" <?= $auto['brandstof'] === 'Benzine' ? 'selected' : '' ?>>Benzine</option>
                            <option value="Diesel" <?= $auto['brandstof'] === 'Diesel' ? 'selected' : '' ?>>Diesel</option>
                            <option value="Elektrisch" <?= $auto['brandstof'] === 'Elektrisch' ? 'selected' : '' ?>>Elektrisch</option>
                            <option value="Hybride" <?= $auto['brandstof'] === 'Hybride' ? 'selected' : '' ?>>Hybride</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="transmissie" class="form-label">Transmissie</label>
                        <select class="form-select" id="transmissie" name="transmissie" required>
                            <option value="Handgeschakeld" <?= $auto['transmissie'] === 'Handgeschakeld' ? 'selected' : '' ?>>Handgeschakeld</option>
                            <option value="Automaat" <?= $auto['transmissie'] === 'Automaat' ? 'selected' : '' ?>>Automaat</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="prijs" class="form-label">Prijs (€)</label>
                        <input type="number" step="0.01" class="form-control" id="prijs" name="prijs" min="0" value="<?= htmlspecialchars($auto['prijs']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="voorraad" class="form-label">Voorraad</label>
                        <input type="number" class="form-control" id="voorraad" name="voorraad" min="0" value="<?= htmlspecialchars($auto['voorraad']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="leverancier_id" class="form-label">Leverancier ID</label>
                        <input type="number" class="form-control" id="leverancier_id" name="leverancier_id" value="<?= htmlspecialchars($auto['leverancier_id']) ?>">
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="beschrijving" class="form-label">Beschrijving</label>
                <textarea class="form-control" id="beschrijving" name="beschrijving" rows="3"><?= htmlspecialchars($auto['beschrijving']) ?></textarea>
            </div>
            
            <div class="mb-3">
                <label for="datum_toegevoegd" class="form-label">Datum Toegevoegd</label>
                <input type="date" class="form-control" id="datum_toegevoegd" name="datum_toegevoegd" value="<?= htmlspecialchars($auto['datum_toegevoegd']) ?>" required>
            </div>
            
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="verkocht" name="verkocht" value="1" <?= $auto['verkocht'] ? 'checked' : '' ?>>
                <label class="form-check-label" for="verkocht">Verkocht</label>
            </div>
            
            <button type="submit" class="btn btn-primary">Opslaan</button>
            <a href="index.php" class="btn btn-secondary">Annuleren</a>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>