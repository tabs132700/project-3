<?php
require_once 'config.php';

// Functie om alle auto's op te halen (exclusief verwijderde als soft delete actief is)
function getAllAutos($includeDeleted = false) {
    global $pdo;
    $sql = "SELECT * FROM autos";
    if (!$includeDeleted && columnExists('autos', 'is_verwijderd')) {
        $sql .= " WHERE is_verwijderd = 0";
    }
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Functie om een specifieke auto op te halen
function getAutoById($id) {
    global $pdo;
    $sql = "SELECT * FROM autos WHERE auto_id = ?";
    if (columnExists('autos', 'is_verwijderd')) {
        $sql .= " AND is_verwijderd = 0";
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Functie om een nieuwe auto toe te voegen
function addAuto($data) {
    global $pdo;
    $sql = "INSERT INTO autos (model_id, merk_id, bouwjaar, kleur, kilometerstand, brandstof, transmissie, prijs, beschrijving, voorraad, leverancier_id, datum_toegevoegd, verkocht" . 
           (columnExists('autos', 'is_verwijderd') ? ", is_verwijderd" : "") . ") 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?" . (columnExists('autos', 'is_verwijderd') ? ", 0" : "") . ")";
    
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([
        $data['model_id'],
        $data['merk_id'],
        $data['bouwjaar'],
        $data['kleur'],
        $data['kilometerstand'],
        $data['brandstof'],
        $data['transmissie'],
        $data['prijs'],
        $data['beschrijving'],
        $data['voorraad'],
        $data['leverancier_id'],
        $data['datum_toegevoegd'],
        $data['verkocht'] ?? 0
    ]);
}

// Functie om een auto bij te werken
function updateAuto($id, $data) {
    global $pdo;
    $sql = "UPDATE autos SET 
            model_id = ?,
            merk_id = ?,
            bouwjaar = ?,
            kleur = ?,
            kilometerstand = ?,
            brandstof = ?,
            transmissie = ?,
            prijs = ?,
            beschrijving = ?,
            voorraad = ?,
            leverancier_id = ?,
            datum_toegevoegd = ?,
            verkocht = ?
            WHERE auto_id = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([
        $data['model_id'],
        $data['merk_id'],
        $data['bouwjaar'],
        $data['kleur'],
        $data['kilometerstand'],
        $data['brandstof'],
        $data['transmissie'],
        $data['prijs'],
        $data['beschrijving'],
        $data['voorraad'],
        $data['leverancier_id'],
        $data['datum_toegevoegd'],
        $data['verkocht'] ?? 0,
        $id
    ]);
}

// Functie om een auto te verwijderen (soft delete of cascade)
function deleteAuto($id) {
    global $pdo;
    
    // Optie 1: Soft delete als de kolom bestaat
    if (columnExists('autos', 'is_verwijderd')) {
        $stmt = $pdo->prepare("UPDATE autos SET is_verwijderd = 1 WHERE auto_id = ?");
        return $stmt->execute([$id]);
    }
    // Optie 2: Cascade delete met transactie
    else {
        $pdo->beginTransaction();
        try {
            // Verwijder eerst gerelateerde bestelling items
            if (tableExists('bestellingen_items')) {
                $stmt = $pdo->prepare("DELETE FROM bestellingen_items WHERE auto_id = ?");
                $stmt->execute([$id]);
            }
            
            // Verwijder dan de auto
            $stmt = $pdo->prepare("DELETE FROM autos WHERE auto_id = ?");
            $stmt->execute([$id]);
            
            $pdo->commit();
            return true;
        } catch (PDOException $e) {
            $pdo->rollBack();
            return false;
        }
    }
}

// Hulpfunctie om te controleren of een kolom bestaat
function columnExists($table, $column) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
        $stmt->execute([$table, $column]);
        return $stmt->fetch() !== false;
    } catch (PDOException $e) {
        return false;
    }
}

// Hulpfunctie om te controleren of een tabel bestaat
function tableExists($table) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
        $stmt->execute([$table]);
        return $stmt->fetch() !== false;
    } catch (PDOException $e) {
        return false;
    }
}
?>