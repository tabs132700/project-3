<?php
require_once 'functions.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];

if (deleteAuto($id)) {
    header("Location: index.php?success=1");
} else {
    header("Location: index.php?error=1");
}
exit();
?>