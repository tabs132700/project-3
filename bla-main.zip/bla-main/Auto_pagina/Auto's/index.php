<?php
require_once 'functions.php';
$autos = getAllAutos();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto's Beheren</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="header">
        <div class="logo">
            <!-- Logo kan hier worden toegevoegd -->
        </div>
        <h1 class="title">Auto's</h1>
        <nav class="navbar">
            <a href="http://localhost/Project3-main/Home%20pagina/Home/homepage.html" class="nav-link active">Home</a>
            <a href="http://localhost/Project3-main/Home%20pagina/Klanten/klanten.php" class="nav-link">Klanten</a>
            <a href="http://localhost/Project3-main/Home%20pagina/Bestelingen/" class="nav-link">Bestellingen</a>
            <a href="#" class="nav-link">Contact</a>
            <a href="#" class="nav-link">Log in</a>
        </nav>
    </header>
    
    <main class="container">
        <section class="producten-grid">
            <div class="container mt-5">
                <h1>Auto's Beheren</h1>
                <a href="create.php" class="btn btn-primary mb-3">Nieuwe Auto Toevoegen</a>
                <a href="http://localhost/Project3-main/Home%20pagina/Auto_pagina/Auto's_fotos/" class="btn btn-primary mb-3">Auto Fotos</a>
                <a href="http://localhost/Project3-main/Home%20pagina/Auto_pagina/Merken/" class="btn btn-primary mb-3">Merken</a>
                <a href="http://localhost/Project3-main/Home%20pagina/Auto_pagina/Modellen/" class="btn btn-primary mb-3">Models</a>
                
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Merk</th>
                            <th>Model</th>
                            <th>Bouwjaar</th>
                            <th>Kleur</th>
                            <th>Kilometerstand</th>
                            <th>Brandstof</th>
                            <th>Prijs</th>
                            <th>Acties</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($autos as $auto): ?>
                        <tr>
                            <td><?= htmlspecialchars($auto['auto_id']) ?></td>
                            <td><?= htmlspecialchars($auto['merk_id']) ?></td>
                            <td><?= htmlspecialchars($auto['model_id']) ?></td>
                            <td><?= htmlspecialchars($auto['bouwjaar']) ?></td>
                            <td><?= htmlspecialchars($auto['kleur']) ?></td>
                            <td><?= htmlspecialchars($auto['kilometerstand']) ?></td>
                            <td><?= htmlspecialchars($auto['brandstof']) ?></td>
                            <td>€<?= number_format($auto['prijs'], 2, ',', '.') ?></td>
                            <td>
                                <a href="edit.php?id=<?= $auto['auto_id'] ?>" class="btn btn-sm btn-warning">Bewerken</a>
                                <a href="delete.php?id=<?= $auto['auto_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Weet u zeker dat u deze auto wilt verwijderen?')">Verwijderen</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        </section>
    </main>
    
  
    </footer>
</body>
</html>